/*--- (C) 1999-2017 Techniker Krankenkasse ---*/

package ez4eva.extendedclipboard.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayer;
import javax.swing.border.LineBorder;

public class OverlayFrame extends JFrame {

	public static final Color BG_COLOR_SELECTED_SLOT = new Color(106, 244, 51, 128);
	public static final Color BG_COLOR_NOTHING = new Color(255, 255, 255, 0);

	private List<ClipboardSelection> selections;
	private ClipboardSelection currentClipboard;

	public OverlayFrame() {
		super();
	}

	public void init() {
		this.setUndecorated(true);
		this.setBackground(new Color(128, 128, 128, 150));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 600);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(
			dim.width / 2 - this.getSize().width / 2,
			dim.height / 2 - this.getSize().height / 2
		);
		GridLayout layout = new GridLayout(3, 3);
		this.setLayout(layout);

		Font labelFont = new Font("Times New Roman", Font.BOLD, 15);
		Color labelColor = new Color(255, 255, 255, 255);
		selections = new ArrayList<>();

		for (int i = 0; i < 9; i++) {
			ClipboardSelection label = new ClipboardSelection();
			label.setText("");
			label.setForeground(labelColor);
			label.setFont(labelFont);
			label.setBorder(new LineBorder(Color.BLACK));
			label.setBackground(BG_COLOR_NOTHING);
			label.setOpaque(true);

			NumberLayer ui = new NumberLayer(getNummer(i));
			JLayer<JLabel> layer = new JLayer<>(label, ui);

			selections.add(label);
			this.add(layer);
		}
		selectPanel(6);
	}

	public List<ClipboardSelection> getPanels() {
		return selections;
	}

	private void resetBackgrounds() {
		for (JLabel panel : selections) {
			panel.setBackground(BG_COLOR_NOTHING);
		}
	}

	public void selectPanel(int i) {
		resetBackgrounds();
		ClipboardSelection selection = selections.get(i);
		currentClipboard = selection;
		selection.setBackground(BG_COLOR_SELECTED_SLOT);
	}

	public void saveClipboardData() {
		Transferable contents = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
		currentClipboard.setClipboardData(contents);

		if (contents.isDataFlavorSupported(DataFlavor.stringFlavor)) {
			try {
				currentClipboard.setText(
					(String) contents.getTransferData(DataFlavor.stringFlavor)
				);
			} catch (UnsupportedFlavorException | IOException e) {
				e.printStackTrace();
			}
		} else if (contents.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
			try {
				String text = "<html><body><p><u>Dateien:</u></p><br>";
				List<File> fileList =
					(List<File>) contents.getTransferData(DataFlavor.javaFileListFlavor);
				for (File f : fileList) {
					text += f.getName() + "<br>";
				}
				text += "</body></html>";
				currentClipboard.setText(text);
			} catch (UnsupportedFlavorException | IOException e) {
				e.printStackTrace();
				currentClipboard.setText("Daten");
			}

		} else {
			currentClipboard.setText("Daten");
		}
	}

	public void loadClipboardData() {
		if (currentClipboard.getClipboardData() != null) {
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(
				currentClipboard.getClipboardData(),
				null
			);
		}
	}

	private static int getNummer(int index) {
		int[] zahlen = { 7, 8, 9, 4, 5, 6, 1, 2, 3 };
		return zahlen[index];
	}

	public ClipboardSelection getCurrentSeleciton() {
		return currentClipboard;
	}
}

/*--- Formatiert nach TK Code Konventionen vom 05.03.2002 ---*/
