package ez4eva.extendedclipboard.listener;

import ez4eva.extendedclipboard.ui.OverlayFrame;

import java.util.Set;

import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

public class OverlayKeyListener implements NativeKeyListener {
	private final OverlayFrame frame;
	private final Set<Integer> pressedKeys;

	public OverlayKeyListener(OverlayFrame frame, Set<Integer> pressedKeys) {
		this.frame = frame;
		this.pressedKeys = pressedKeys;
	}

	@Override
	public void nativeKeyTyped(NativeKeyEvent e) {
	}

	@Override
	public void nativeKeyReleased(NativeKeyEvent e) {
		pressedKeys.remove(Integer.valueOf(e.getKeyCode()));
		updateScreenVisible(frame);

	}

	@Override
	public void nativeKeyPressed(NativeKeyEvent e) {
		pressedKeys.add(Integer.valueOf(e.getKeyCode()));
		updateScreenVisible(frame);
		if (frame.isVisible()) {
			switch (e.getKeyCode()) {

				case NativeKeyEvent.VC_KP_9 :
					frame.selectPanel(2);
					break;

				case NativeKeyEvent.VC_KP_8 :
					frame.selectPanel(1);
					break;

				case NativeKeyEvent.VC_KP_7 :
					frame.selectPanel(0);
					break;

				case NativeKeyEvent.VC_KP_6 :
					frame.selectPanel(5);
					break;

				case NativeKeyEvent.VC_KP_5 :
					frame.selectPanel(4);
					break;

				case NativeKeyEvent.VC_KP_4 :
					frame.selectPanel(3);
					break;

				case NativeKeyEvent.VC_KP_3 :
					frame.selectPanel(8);
					break;

				case NativeKeyEvent.VC_KP_2 :
					frame.selectPanel(7);
					break;

				case NativeKeyEvent.VC_KP_1 :
					frame.selectPanel(6);
					break;

				default :
					break;
			}
		}
	}

	private void updateScreenVisible(final OverlayFrame frame) {
		if (
			pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_CONTROL_L))
			&& pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_ALT_L))

//          && (
//              pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_1))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_2))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_3))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_4))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_5))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_6))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_7))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_8))
//              || pressedKeys.contains(Integer.valueOf(NativeKeyEvent.VC_KP_9))
//              || frame.isVisible()
//          )
		) {
			if (!frame.isVisible()) {
				frame.saveClipboardData();
				frame.setVisible(true);
			}
		} else {
			if (frame.isVisible()) {
				frame.loadClipboardData();
				frame.setVisible(false);
			}
		}
	}
}