package ez4eva.extendedclipboard.ui;

import java.awt.datatransfer.Transferable;

import javax.swing.JLabel;

import org.apache.commons.lang3.StringEscapeUtils;

public class ClipboardSelection extends JLabel {

	private static final long serialVersionUID = 1L;
	private Transferable clipboardData;

	public Transferable getClipboardData() {
		return clipboardData;
	}

	public void setClipboardData(Transferable clipboardData) {
		this.clipboardData = clipboardData;
	}

	@Override
	public void setText(String text) {
		String string = StringEscapeUtils.escapeHtml4(text);
		string = string.replace("\r\n", "\n");
		string = string.replace("\r", "\n");
		string = string.replace("\n", "<br/>");
		string = string.replace("\t", "&emsp;");
		super.setText(
			"<html><body><span style='word-break: break-all;line-break:break-all;'>" + string
			+ "</span></body></html>"
		);
	}
}