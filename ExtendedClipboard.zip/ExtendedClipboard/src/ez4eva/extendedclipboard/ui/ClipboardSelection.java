package ez4eva.extendedclipboard.ui;

import java.awt.datatransfer.Transferable;

import javax.swing.JLabel;

public class ClipboardSelection extends JLabel {

	private Transferable clipboardData;

	public Transferable getClipboardData() {
		return clipboardData;
	}

	public void setClipboardData(Transferable clipboardData) {
		this.clipboardData = clipboardData;
	}

}