package ez4eva.extendedclipboard.ui;

import ez4eva.extendedclipboard.listener.OverlayKeyListener;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.FlavorEvent;
import java.awt.datatransfer.FlavorListener;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

public class Main {

	public static void main(String[] args) {
		final List<Transferable> trans = new ArrayList<Transferable>();
		System.err.close();

		Toolkit.getDefaultToolkit().getSystemClipboard().addFlavorListener(
			new FlavorListener() {

				@Override
				public void flavorsChanged(FlavorEvent e) {
					Clipboard clipboard = (Clipboard) e.getSource();
					System.out.println(e.getSource());
					DataFlavor[] flavors = clipboard.getAvailableDataFlavors();
					System.out.println(Arrays.toString(flavors));
					for (DataFlavor f : flavors) {
						try {
							System.out.println(f.getMimeType() + ": " + clipboard.getData(f));
						} catch (UnsupportedFlavorException | IOException e1) {
							e1.printStackTrace();
						}
					}
					trans.add(clipboard.getContents(null));
				}
			}
		);

		OverlayFrame frame = new OverlayFrame();

		frame.init();

		final Set<Integer> pressedKeys = new HashSet<Integer>();
		try {
			GlobalScreen.registerNativeHook();
		} catch (NativeHookException e1) {
			e1.printStackTrace();
		}
		GlobalScreen.addNativeKeyListener(new OverlayKeyListener(frame, pressedKeys));

	}
}