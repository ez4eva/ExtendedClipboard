package ez4eva.extendedclipboard.ui;

import ez4eva.extendedclipboard.listener.OverlayKeyListener;

import java.util.HashSet;
import java.util.Set;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

public class Main {

	public static void main(String[] args) {
		System.err.close();
		OverlayFrame frame = new OverlayFrame();

		frame.init();

		final Set<Integer> pressedKeys = new HashSet<Integer>();
		try {
			GlobalScreen.registerNativeHook();
		} catch (NativeHookException e1) {
			e1.printStackTrace();
		}
		GlobalScreen.addNativeKeyListener(new OverlayKeyListener(frame, pressedKeys));

	}
}