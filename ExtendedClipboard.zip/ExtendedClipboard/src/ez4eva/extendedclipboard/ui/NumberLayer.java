package ez4eva.extendedclipboard.ui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.plaf.LayerUI;

public class NumberLayer extends LayerUI<JLabel> {
	private int number;

	public NumberLayer(int number) {
		this.number = number;
	}

	@Override
	public void paint(Graphics g, JComponent c) {
		super.paint(g, c);
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
		g2.setColor(new Color(255, 255, 255, 96));
		g2.setFont(new Font("Arial", Font.BOLD, 150));
		Rectangle2D bounds =
			g2.getFont().getStringBounds(Integer.toString(number), g2.getFontRenderContext());
		g2.drawString(
			Integer.toString(number),
			(int) (c.getWidth() - bounds.getWidth()) / 2f,
			(int) (c.getHeight() - 50)
		);
		System.out.println(bounds.getHeight());
//      g2.fillRect(0, 0, c.getWidth(), c.getHeight());

//      g2.setColor(c.getBackground());
//      g2.fillRect(0, 0, c.getSize().width, c.getSize().height);
//      g2.setFont(new Font("Arial", Font.BOLD, 50));
//      g2.setColor(Color.BLACK);
//      g2.drawString(Integer.toString(number), 0, 0);
		g2.dispose();
	}
}